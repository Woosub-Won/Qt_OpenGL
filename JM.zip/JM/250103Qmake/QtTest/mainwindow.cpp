#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QtOpenGLWidgets/QtOpenGLWidgets>
#include <QtOpenGLWidgets/QOpenGLWidget>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    setWindowTitle("Qt Test");

    //create opengl widget
    QOpenGLWidget* openGLWidget = new  QOpenGLWidget(this);

    ui->verticalLayout->addWidget(openGLWidget);

}

MainWindow::~MainWindow()
{
    delete ui;
}
