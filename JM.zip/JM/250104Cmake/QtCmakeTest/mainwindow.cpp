#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QtOpenGLWidgets/QOpenGLWidget>
#include "triangleglwidget.h"
#include "rectangleglwidget.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    setWindowTitle("Qt Cmake Test");


    TriangleGlWidget* triangleGLWidget = new TriangleGlWidget(this);
    //rectangleGlWidget* rGLWidget = new rectangleGlWidget(this);

    ui->verticalLayout_2->addWidget(triangleGLWidget);


}

MainWindow::~MainWindow()
{
    delete ui;
}
