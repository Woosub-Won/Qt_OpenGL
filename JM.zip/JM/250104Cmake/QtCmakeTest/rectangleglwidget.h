#ifndef RECTANGLEGLWIDGET_H
#define RECTANGLEGLWIDGET_H

#include <QOpenGLWidget>
#include <QObject>
#include <QOpenGLFunctions>

class rectangleGlWidget : public QOpenGLWidget, protected QOpenGLFunctions
{
    Q_OBJECT
public:
    rectangleGlWidget(QWidget* parent = nullptr);
    ~rectangleGlWidget();
protected:

    void initializeGL();
    void paintGL();
};

#endif // RECTANGLEGLWIDGET_H
