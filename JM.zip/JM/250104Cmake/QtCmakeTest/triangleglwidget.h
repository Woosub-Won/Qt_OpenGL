#ifndef TRIANGLEGLWIDGET_H
#define TRIANGLEGLWIDGET_H

#include <QObject>
#include <QOpenGLWidget>
#include <QOpenGLFunctions>

class TriangleGlWidget : public QOpenGLWidget, protected QOpenGLFunctions
{
    Q_OBJECT
public:
    TriangleGlWidget(QWidget* parent = nullptr);
    ~TriangleGlWidget();

protected:
    void initializeGL();
    void paintGL();


private:
    float vertices[9] = {
        -0.5f, -0.5f, 0.0f,
        0.5f, -0.5f, 0.0f,
        0.0f,  0.5f, 0.0f
    };


};

#endif // TRIANGLEGLWIDGET_H
