#include "rectangleglwidget.h"

rectangleGlWidget::rectangleGlWidget(QWidget *parent):QOpenGLWidget(parent) {


}

rectangleGlWidget::~rectangleGlWidget()
{

}

void rectangleGlWidget::initializeGL()
{
    initializeOpenGLFunctions();

    glClearColor(1,1,1,1);
}

void rectangleGlWidget::paintGL()
{

}

